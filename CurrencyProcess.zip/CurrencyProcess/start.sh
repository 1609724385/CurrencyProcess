java -Xmx1024M -Xms1024M -cp target/CurrencyProcess.jar com.hsbc.data.CurrencyProcess
